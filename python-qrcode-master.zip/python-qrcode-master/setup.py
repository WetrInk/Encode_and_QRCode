#!/usr/bin/env python
from setuptools import setup

# See setup.cfg for configuration.
setup(
    data_files=[('share/man/man1', ['doc/qr.1'])],
)
